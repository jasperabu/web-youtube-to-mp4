import { Volume2, VolumeX } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const [soundEnabled, setSoundEnabled] = useState(false);

  const toggleSound = () => {
    setSoundEnabled(!soundEnabled);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50" style={{
      background: 'var(--pixel-dark)',
      borderBottom: '4px solid var(--pixel-blue)'
    }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between" style={{ height: '64px' }}>
          <div className="flex items-center gap-4">
            <div className="header-glow flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-[var(--pixel-blue)] to-[var(--pixel-green)]"
                   style={{
                     boxShadow: '0 0 0 2px var(--pixel-blue-dark), 4px 4px 0 var(--pixel-darker)'
                   }}>
              </div>
              <h1 className="text-sm sm:text-base" style={{
                color: 'var(--pixel-blue)',
                letterSpacing: '2px',
                textShadow: '2px 2px 0 var(--pixel-blue-dark)'
              }}>
                RETRO
              </h1>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <a href="#" className="pixel-link text-xs">HOME</a>
            <a href="#" className="pixel-link text-xs">TOOLS</a>
            <a href="#" className="pixel-link text-xs">ABOUT</a>
          </nav>

          <button
            onClick={toggleSound}
            className="flex items-center justify-center w-10 h-10"
            style={{
              background: soundEnabled ? 'var(--pixel-green)' : 'var(--pixel-gray-dark)',
              border: '2px solid var(--pixel-gray)',
              boxShadow: '2px 2px 0 var(--pixel-darker)',
              cursor: 'pointer',
              transition: 'all 0.1s steps(2)'
            }}
            aria-label={soundEnabled ? 'Mute sound' : 'Enable sound'}
          >
            {soundEnabled ? (
              <Volume2 size={20} style={{ color: 'var(--pixel-black)' }} />
            ) : (
              <VolumeX size={20} style={{ color: 'var(--pixel-white)' }} />
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
