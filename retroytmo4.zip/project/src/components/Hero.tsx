import { Download, Video, Music, FileText } from 'lucide-react';
import { useState } from 'react';

type FormatType = 'mp4' | 'mp3' | 'subtitle';

export default function Hero() {
  const [url, setUrl] = useState('');
  const [selectedFormat, setSelectedFormat] = useState<FormatType>('mp4');
  const [isDownloading, setIsDownloading] = useState(false);
  const [progress, setProgress] = useState(0);

  const formats: { type: FormatType; label: string; icon: JSX.Element }[] = [
    { type: 'mp4', label: 'VIDEO', icon: <Video size={16} /> },
    { type: 'mp3', label: 'AUDIO', icon: <Music size={16} /> },
    { type: 'subtitle', label: 'SUBS', icon: <FileText size={16} /> },
  ];

  const handleDownload = () => {
    if (!url.trim()) return;

    setIsDownloading(true);
    setProgress(0);

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsDownloading(false);
          return 0;
        }
        return prev + 12.5;
      });
    }, 300);
  };

  return (
    <div className="pixel-bg min-h-screen pt-20 pb-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8 mt-12">
          <h1 className="pixel-title mb-4">
            YOUTUBE → MP4
          </h1>
          <p className="pixel-subtitle">
            PASTE · DOWNLOAD · ENJOY
          </p>
        </div>

        <div className="pixel-panel mb-8">
          <div className="flex gap-2 mb-6 flex-wrap">
            {formats.map((format) => (
              <button
                key={format.type}
                className={`pixel-tab flex items-center gap-2 ${
                  selectedFormat === format.type ? 'active' : ''
                }`}
                onClick={() => setSelectedFormat(format.type)}
              >
                {format.icon}
                {format.label}
              </button>
            ))}
          </div>

          <div className="mb-6">
            <input
              type="text"
              className="pixel-input"
              placeholder="ENTER YOUTUBE URL..."
              value={url}
              onChange={(e) => setUrl(e.target.value)}
            />
          </div>

          {isDownloading && (
            <div className="pixel-progress mb-6">
              <div
                className="pixel-progress-bar"
                style={{ width: `${progress}%` }}
              >
                {progress > 20 && `${Math.round(progress)}%`}
              </div>
            </div>
          )}

          <button
            className="pixel-btn large w-full flex items-center justify-center gap-3"
            onClick={handleDownload}
            disabled={isDownloading || !url.trim()}
          >
            <Download size={20} />
            {isDownloading ? 'DOWNLOADING...' : 'DOWNLOAD'}
          </button>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="pixel-panel-inset">
            <h3 className="text-xs mb-4" style={{ color: 'var(--pixel-blue)' }}>
              HOW TO USE
            </h3>
            <ol className="text-xs space-y-3" style={{ color: 'var(--pixel-gray)', lineHeight: '1.8' }}>
              <li>1. COPY VIDEO URL</li>
              <li>2. PASTE IN BOX</li>
              <li>3. SELECT FORMAT</li>
              <li>4. HIT DOWNLOAD</li>
            </ol>
          </div>

          <div className="pixel-panel-inset">
            <h3 className="text-xs mb-4" style={{ color: 'var(--pixel-green)' }}>
              FEATURES
            </h3>
            <ul className="text-xs space-y-3" style={{ color: 'var(--pixel-gray)', lineHeight: '1.8' }}>
              <li>→ HD QUALITY</li>
              <li>→ FAST SPEED</li>
              <li>→ NO ADS</li>
              <li>→ 100% FREE</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
